import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import PersonalBot from './PersonalBot'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PersonalBot />
  </React.StrictMode>,
)