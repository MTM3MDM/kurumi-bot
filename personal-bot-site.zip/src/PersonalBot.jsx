import { useState } from "react";

export default function PersonalBot() {
  const [messages, setMessages] = useState([
    { role: "bot", text: "안녕하세요! 무엇을 도와드릴까요?" }
  ]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (!input.trim()) return;
    const newMessage = { role: "user", text: input };
    setMessages([...messages, newMessage, { role: "bot", text: "응답 생성 중..." }]);
    setInput("");
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6 flex flex-col items-center">
      <h1 className="text-4xl font-bold mb-6">나만의 AI 챗봇</h1>
      <div className="w-full max-w-2xl bg-white shadow-xl rounded-xl p-4 space-y-4">
        <div className="h-96 overflow-y-auto border border-gray-200 rounded-lg p-4 bg-gray-50">
          {messages.map((msg, idx) => (
            <div key={idx} className={`text-${msg.role === "bot" ? "blue" : "gray"}-700 mb-2`}>
              <strong>{msg.role === "bot" ? "봇" : "나"}:</strong> {msg.text}
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            className="flex-1 border border-gray-300 rounded px-3 py-2"
            placeholder="메시지를 입력하세요..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />
          <button onClick={sendMessage} className="bg-blue-600 text-white px-4 py-2 rounded">전송</button>
        </div>
      </div>
    </div>
  );
}